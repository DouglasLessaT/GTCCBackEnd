package br.gtcc.gtcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GtccApplicationTests {

	@Test
	void contextLoads() {
	}

}
